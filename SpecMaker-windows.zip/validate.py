import re

from storage.catalog import VALID_TYPES

ALNUM_PATTERN = re.compile(r"^[A-Za-z0-9_-]+$")


class ValidationError(Exception):
    pass


def validate_catalog(data):
    variables = data.get("variables", [])
    seen = set()
    for idx, var in enumerate(variables):
        var_id = var.get("id", "").strip()
        if not var_id:
            raise ValidationError(f"Variable #{idx + 1} is missing an id.")
        if var_id in seen:
            raise ValidationError(f"Duplicate variable id: {var_id}")
        seen.add(var_id)

        var_type = var.get("type", "")
        if var_type not in VALID_TYPES:
            raise ValidationError(f"Variable '{var_id}' has invalid type '{var_type}'.")

        if var_type == "dropdown":
            options = var.get("options") or []
            if not options:
                raise ValidationError(f"Dropdown variable '{var_id}' requires options.")


def validate_template(data, catalog):
    validate_catalog(catalog)

    meta = data.get("meta") or {}
    for key in ("id", "version", "title"):
        if not meta.get(key):
            raise ValidationError(f"Template meta.{key} is required.")

    catalog_ids = {v["id"] for v in catalog.get("variables", [])}
    sections = data.get("sections") or []
    if not sections:
        raise ValidationError("Template must contain at least one section.")

    section_ids = set()
    has_fields_block = False

    for section in sections:
        sid = section.get("id", "").strip()
        if not sid:
            raise ValidationError("Each section must have an id.")
        if sid in section_ids:
            raise ValidationError(f"Duplicate section id: {sid}")
        section_ids.add(sid)

        for block in section.get("blocks") or []:
            block_type = block.get("type")
            if block_type == "divider":
                continue
            if block_type != "fields":
                raise ValidationError(f"Unknown block type in section '{sid}'.")
            has_fields_block = True
            for field_id in block.get("fields") or []:
                if field_id not in catalog_ids:
                    raise ValidationError(
                        f"Field '{field_id}' in section '{sid}' is not in the catalog."
                    )

    if not has_fields_block:
        raise ValidationError("Template must contain at least one fields block.")


def validate_study_values(values, template, catalog):
    expected = set()
    for section in template.get("sections", []):
        for block in section.get("blocks", []):
            if block.get("type") == "fields":
                expected.update(block.get("fields", []))

    actual = set(values.keys())
    if actual != expected:
        missing = expected - actual
        extra = actual - expected
        parts = []
        if missing:
            parts.append(f"missing: {', '.join(sorted(missing))}")
        if extra:
            parts.append(f"extra: {', '.join(sorted(extra))}")
        raise ValidationError("Study values do not match template fields (" + "; ".join(parts) + ").")

    var_map = {v["id"]: v for v in catalog.get("variables", [])}
    normalized = {}

    for field_id in expected:
        raw = values.get(field_id, "")
        if raw is None:
            raw = ""
        if isinstance(raw, str):
            raw = raw.strip()
        var = var_map.get(field_id)
        if not var:
            raise ValidationError(f"Unknown variable '{field_id}'.")

        var_type = var.get("type")
        if var_type == "number":
            if raw == "":
                normalized[field_id] = ""
            else:
                try:
                    num = float(raw)
                    normalized[field_id] = int(num) if num.is_integer() else num
                except ValueError as exc:
                    raise ValidationError(f"'{field_id}' must be a number.") from exc
        elif var_type == "dropdown":
            if raw == "":
                normalized[field_id] = ""
            elif raw not in (var.get("options") or []):
                raise ValidationError(f"'{field_id}' must be one of: {', '.join(var['options'])}")
            else:
                normalized[field_id] = raw
        elif var_type == "alphanumeric":
            if raw == "":
                normalized[field_id] = ""
            elif not ALNUM_PATTERN.match(str(raw)):
                raise ValidationError(f"'{field_id}' must be alphanumeric (letters, numbers, _, -).")
            else:
                normalized[field_id] = str(raw)
        else:
            normalized[field_id] = str(raw)

    return normalized
