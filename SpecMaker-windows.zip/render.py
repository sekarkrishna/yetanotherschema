from storage.catalog import variables_by_id
from storage.templates_io import collect_field_ids


def build_study_context(template, catalog, values=None):
    var_map = variables_by_id(catalog)
    values = values or {}
    sections = []

    for section in template.get("sections", []):
        rendered_section = {"id": section["id"], "title": section.get("title", ""), "blocks": []}
        for block in section.get("blocks", []):
            if block.get("type") == "divider":
                rendered_section["blocks"].append({"type": "divider"})
                continue
            fields = []
            for field_id in block.get("fields", []):
                var = var_map.get(field_id, {"id": field_id, "label": field_id, "type": "text"})
                fields.append(
                    {
                        "id": field_id,
                        "label": var.get("label", field_id),
                        "type": var.get("type", "text"),
                        "options": var.get("options", []),
                        "value": values.get(field_id, ""),
                    }
                )
            rendered_section["blocks"].append({"type": "fields", "fields": fields})
        sections.append(rendered_section)

    return {
        "sections": sections,
        "field_ids": collect_field_ids(template),
        "template_meta": template.get("meta", {}),
    }


def format_display_value(value):
    if value is None or value == "":
        return None
    return value
