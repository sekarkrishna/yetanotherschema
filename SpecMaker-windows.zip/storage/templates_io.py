import tomllib

import tomli_w

from config import TEMPLATES_DIR


def list_templates():
    files = sorted(TEMPLATES_DIR.glob("*.toml"))
    return [{"filename": f.name, "path": f} for f in files]


def template_filename(meta):
    return f"{meta['id']}_v{meta['version']}.toml"


def load_template(filename):
    path = TEMPLATES_DIR / filename
    with open(path, "rb") as f:
        data = tomllib.load(f)
    data["_filename"] = filename
    return data


def save_template(data):
    meta = data["meta"]
    filename = template_filename(meta)
    path = TEMPLATES_DIR / filename
    payload = {"meta": meta, "sections": data.get("sections", [])}
    with open(path, "wb") as f:
        tomli_w.dump(payload, f)
    return filename


def collect_field_ids(template):
    ids = []
    for section in template.get("sections", []):
        for block in section.get("blocks", []):
            if block.get("type") == "fields":
                ids.extend(block.get("fields", []))
    return ids


def find_template_file(template_id, version):
    filename = f"{template_id}_v{version}.toml"
    path = TEMPLATES_DIR / filename
    if path.exists():
        return filename
    for item in list_templates():
        data = load_template(item["filename"])
        meta = data.get("meta", {})
        if meta.get("id") == template_id and meta.get("version") == version:
            return item["filename"]
    return None
