import tomllib

import tomli_w

from config import CATALOG_PATH

VALID_TYPES = {"text", "number", "alphanumeric", "dropdown"}


def load_catalog():
    with open(CATALOG_PATH, "rb") as f:
        return tomllib.load(f)


def save_catalog(data):
    with open(CATALOG_PATH, "wb") as f:
        tomli_w.dump(data, f)


def variables_by_id(catalog):
    return {v["id"]: v for v in catalog.get("variables", [])}


def variables_by_group(catalog):
    groups = {}
    for var in catalog.get("variables", []):
        group = var.get("group", "other")
        groups.setdefault(group, []).append(var)
    return groups
