import tomllib
from datetime import date

import tomli_w

from config import STUDIES_DIR


def list_studies():
    files = sorted(STUDIES_DIR.glob("*.toml"))
    studies = []
    for f in files:
        with open(f, "rb") as fh:
            data = tomllib.load(fh)
        meta = data.get("meta", {})
        studies.append(
            {
                "filename": f.name,
                "id": meta.get("id", f.stem),
                "title": meta.get("title", ""),
                "template_id": meta.get("template_id", ""),
                "template_version": meta.get("template_version", ""),
            }
        )
    return studies


def load_study(study_id):
    path = STUDIES_DIR / f"{study_id}.toml"
    with open(path, "rb") as f:
        return tomllib.load(f)


def save_study(data):
    study_id = data["meta"]["id"]
    path = STUDIES_DIR / f"{study_id}.toml"
    if "created" not in data["meta"]:
        data["meta"]["created"] = date.today().isoformat()
    payload = {"meta": data["meta"], "values": data.get("values", {})}
    with open(path, "wb") as f:
        tomli_w.dump(payload, f)
    return study_id
