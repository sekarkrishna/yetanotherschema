from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
CATALOG_PATH = DATA_DIR / "catalog.toml"
TEMPLATES_DIR = DATA_DIR / "templates"
STUDIES_DIR = DATA_DIR / "studies"
