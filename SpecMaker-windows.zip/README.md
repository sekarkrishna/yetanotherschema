# SpecMaker

Minimal POC for collecting specifications from versioned templates. All data is stored as TOML files on disk — no database.

## Concepts

- **Catalog** (`data/catalog.toml`) — global variable library (types: text, number, alphanumeric, dropdown)
- **Templates** (`data/templates/*.toml`) — composed from catalog variables, organized in sections with dividers
- **Studies** (`data/studies/*.toml`) — filled values against a fixed template; no add/remove fields

## Setup

Requires Python 3.11+.

```bash
cd SpecMaker
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Run

```bash
flask --app app run --debug
```

Open http://127.0.0.1:5000

## Seed data (7 files)

| File | Purpose |
|------|---------|
| `data/catalog.toml` | Global variable library |
| `data/templates/general_v1.0.toml` | General specification |
| `data/templates/biomarker_v1.0.toml` | Biomarker template v1.0 |
| `data/templates/biomarker_v2.0.toml` | Biomarker template v2.0 (adds fixation_method, removes detection_limit) |
| `data/templates/lab_v1.0.toml` | Laboratory specification |
| `data/studies/STUDY-001.toml` | Study against biomarker v1.0 |
| `data/studies/STUDY-002.toml` | Study against biomarker v2.0 |

## Demo walkthrough (~5 min)

1. **Catalog** — open `/catalog`. Review shared variables (`project_code`, `lab_name`) vs group-specific ones (`biomarker_name`, `instrument_model`).
2. **Templates** — open `/templates`. Load `biomarker_v1.0.toml`, drag variables from the right panel into a field block, save as a new version.
3. **Studies** — open `/studies/new`. Select `biomarker_v1.0.toml`, fill values, save as a new study ID.
4. **Version diff** — create another study from `biomarker_v2.0.toml` and note the different fields.
5. **Print** — open a study's Print view and use the browser **Print / Save as PDF** button.

## Pages

| Route | Description |
|-------|-------------|
| `/catalog` | Edit global variables |
| `/templates` | Build templates from catalog (drag-drop) |
| `/studies` | List studies |
| `/studies/new` | Fill a study from a template |
| `/studies/<id>/print` | Print-friendly view for PDF export |
