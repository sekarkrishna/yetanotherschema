import json

from flask import Flask, flash, redirect, render_template, request, url_for

from config import CATALOG_PATH, STUDIES_DIR, TEMPLATES_DIR
from storage.catalog import VALID_TYPES, load_catalog, save_catalog, variables_by_group
from storage.studies_io import list_studies, load_study, save_study
from storage.templates_io import (
    collect_field_ids,
    find_template_file,
    list_templates,
    load_template,
    save_template,
)
from render import build_study_context
from validate import ValidationError, validate_catalog, validate_study_values, validate_template


def create_app():
    app = Flask(__name__, template_folder="templates_html", static_folder="static")
    app.secret_key = "specmaker-dev-key"

    for path in (CATALOG_PATH.parent, TEMPLATES_DIR, STUDIES_DIR):
        path.mkdir(parents=True, exist_ok=True)

    @app.route("/")
    def index():
        return redirect(url_for("catalog_page"))

    @app.route("/catalog", methods=["GET", "POST"])
    def catalog_page():
        if request.method == "POST":
            ids = request.form.getlist("id")
            labels = request.form.getlist("label")
            types = request.form.getlist("type")
            groups = request.form.getlist("group")
            options_list = request.form.getlist("options")

            variables = []
            for idx, var_id in enumerate(ids):
                var_id = var_id.strip()
                if not var_id:
                    continue
                var = {
                    "id": var_id,
                    "label": labels[idx].strip(),
                    "type": types[idx].strip(),
                    "group": groups[idx].strip() or "other",
                }
                if var["type"] == "dropdown":
                    opts = [o.strip() for o in options_list[idx].split(",") if o.strip()]
                    var["options"] = opts
                variables.append(var)

            data = {
                "meta": {
                    "id": request.form.get("meta_id", "global_catalog"),
                    "version": request.form.get("meta_version", "1.0"),
                    "title": request.form.get("meta_title", "Global Variable Library"),
                },
                "variables": variables,
            }
            try:
                validate_catalog(data)
                save_catalog(data)
                flash("Catalog saved to catalog.toml", "success")
            except ValidationError as exc:
                flash(str(exc), "error")

            return redirect(url_for("catalog_page"))

        catalog = load_catalog()
        return render_template(
            "catalog.html",
            active="catalog",
            catalog=catalog,
            valid_types=sorted(VALID_TYPES),
        )

    @app.route("/templates", methods=["GET", "POST"])
    def templates_page():
        catalog = load_catalog()

        if request.method == "POST":
            try:
                structure = json.loads(request.form.get("structure_json", "{}"))
            except json.JSONDecodeError:
                flash("Invalid template structure.", "error")
                return redirect(url_for("templates_page"))

            data = {
                "meta": {
                    "id": request.form.get("meta_id", "").strip(),
                    "version": request.form.get("meta_version", "").strip(),
                    "title": request.form.get("meta_title", "").strip(),
                    "catalog_id": request.form.get("catalog_id", catalog["meta"]["id"]),
                },
                "sections": structure.get("sections", []),
            }
            try:
                validate_template(data, catalog)
                filename = save_template(data)
                flash(f"Template saved as {filename}", "success")
                return redirect(url_for("templates_page", file=filename))
            except ValidationError as exc:
                flash(str(exc), "error")

        loaded_filename = request.args.get("file", "")
        template = None
        structure = {"sections": []}
        if loaded_filename:
            try:
                template = load_template(loaded_filename)
                structure = {"sections": template.get("sections", [])}
            except FileNotFoundError:
                flash(f"Template file not found: {loaded_filename}", "error")
                loaded_filename = ""

        return render_template(
            "template_builder.html",
            active="templates",
            catalog=catalog,
            catalog_groups=variables_by_group(catalog),
            template=template,
            loaded_filename=loaded_filename,
            structure=structure,
            template_files=list_templates(),
        )

    @app.route("/studies")
    def studies_list():
        return render_template(
            "study_list.html",
            active="studies",
            studies=list_studies(),
        )

    @app.route("/studies/new", methods=["GET", "POST"])
    def study_new():
        catalog = load_catalog()
        templates = []
        for item in list_templates():
            tpl = load_template(item["filename"])
            templates.append({"filename": item["filename"], "meta": tpl["meta"]})

        selected_template = request.args.get("template", request.form.get("template_file", ""))
        study_context = None
        study_id = ""
        study_title = ""

        if selected_template:
            try:
                template = load_template(selected_template)
                study_context = build_study_context(template, catalog)
            except FileNotFoundError:
                flash(f"Template not found: {selected_template}", "error")
                selected_template = ""

        if request.method == "POST" and selected_template:
            study_id = request.form.get("study_id", "").strip()
            study_title = request.form.get("study_title", "").strip()
            template = load_template(selected_template)
            field_ids = collect_field_ids(template)

            values = {}
            for field_id in field_ids:
                values[field_id] = request.form.get(f"field_{field_id}", "")

            try:
                normalized = validate_study_values(values, template, catalog)
                data = {
                    "meta": {
                        "id": study_id,
                        "title": study_title,
                        "template_id": template["meta"]["id"],
                        "template_version": template["meta"]["version"],
                    },
                    "values": normalized,
                }
                save_study(data)
                flash(f"Study saved as {study_id}.toml", "success")
                return redirect(url_for("study_view", study_id=study_id))
            except ValidationError as exc:
                flash(str(exc), "error")
                study_context = build_study_context(template, catalog, values)

        return render_template(
            "study_form.html",
            active="studies",
            templates=templates,
            selected_template=selected_template,
            study_context=study_context,
            study_id=study_id,
            study_title=study_title,
            editing=False,
            template_label="",
        )

    @app.route("/studies/<study_id>/edit", methods=["GET", "POST"])
    def study_edit(study_id):
        catalog = load_catalog()
        try:
            study = load_study(study_id)
        except FileNotFoundError:
            flash(f"Study not found: {study_id}", "error")
            return redirect(url_for("studies_list"))

        template_file = find_template_file(
            study["meta"]["template_id"],
            study["meta"]["template_version"],
        )
        if not template_file:
            flash("Template file for this study was not found.", "error")
            return redirect(url_for("studies_list"))

        template = load_template(template_file)
        study_title = study["meta"].get("title", "")
        values = study.get("values", {})
        study_context = build_study_context(template, catalog, values)

        if request.method == "POST":
            study_title = request.form.get("study_title", "").strip()
            field_ids = collect_field_ids(template)
            submitted = {}
            for field_id in field_ids:
                submitted[field_id] = request.form.get(f"field_{field_id}", "")

            try:
                normalized = validate_study_values(submitted, template, catalog)
                data = {
                    "meta": {
                        "id": study_id,
                        "title": study_title,
                        "template_id": study["meta"]["template_id"],
                        "template_version": study["meta"]["template_version"],
                        "created": study["meta"].get("created"),
                    },
                    "values": normalized,
                }
                save_study(data)
                flash(f"Study {study_id}.toml updated.", "success")
                return redirect(url_for("study_view", study_id=study_id))
            except ValidationError as exc:
                flash(str(exc), "error")
                study_context = build_study_context(template, catalog, submitted)

        return render_template(
            "study_form.html",
            active="studies",
            templates=[],
            selected_template=template_file,
            template_label=f"{study['meta']['template_id']} v{study['meta']['template_version']}",
            study_context=study_context,
            study_id=study_id,
            study_title=study_title,
            editing=True,
        )

    @app.route("/studies/<study_id>")
    def study_view(study_id):
        catalog = load_catalog()
        study = load_study(study_id)
        template_file = find_template_file(
            study["meta"]["template_id"],
            study["meta"]["template_version"],
        )
        if not template_file:
            flash("Template file for this study was not found.", "error")
            return redirect(url_for("studies_list"))

        template = load_template(template_file)
        study_context = build_study_context(template, catalog, study.get("values", {}))
        return render_template(
            "study_view.html",
            active="studies",
            study=study,
            study_context=study_context,
        )

    @app.route("/studies/<study_id>/print")
    def study_print(study_id):
        catalog = load_catalog()
        study = load_study(study_id)
        template_file = find_template_file(
            study["meta"]["template_id"],
            study["meta"]["template_version"],
        )
        template = load_template(template_file)
        study_context = build_study_context(template, catalog, study.get("values", {}))
        return render_template(
            "study_print.html",
            active="studies",
            study=study,
            study_context=study_context,
        )

    return app


if __name__ == "__main__":
    create_app().run(debug=True)
