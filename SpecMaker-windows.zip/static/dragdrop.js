(function () {
  let dragId = null;
  let dragLabel = null;

  document.addEventListener('dragstart', (e) => {
    const chip = e.target.closest('.field-chip[draggable="true"]');
    if (!chip) return;
    dragId = chip.dataset.id;
    dragLabel = chip.dataset.label || dragId;
    e.dataTransfer.setData('text/plain', dragId);
    e.dataTransfer.effectAllowed = 'copy';
  });

  document.addEventListener('dragover', (e) => {
    if (e.target.closest('.sortable-target')) {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
    }
  });

  document.addEventListener('drop', (e) => {
    const target = e.target.closest('.sortable-target');
    if (!target) return;
    e.preventDefault();
    const id = e.dataTransfer.getData('text/plain') || dragId;
    if (!id) return;
    if ([...target.querySelectorAll('.field-chip')].some(c => c.dataset.id === id)) return;
    const label = dragLabel || id;
    const chip = document.createElement('span');
    chip.className = 'field-chip';
    chip.draggable = true;
    chip.dataset.id = id;
    chip.dataset.label = label;
    chip.innerHTML = `${id}<span class="chip-label"> — ${label}</span>`;
    const hint = target.querySelector('span[style]');
    if (hint) hint.remove();
    target.insertBefore(chip, target.querySelector('div'));
    dragId = null;
    dragLabel = null;
  });
})();
